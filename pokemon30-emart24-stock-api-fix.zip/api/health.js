export default async function handler(request) {
  return Response.json({ok:true,service:"pokemon30-emart24-stock",time:new Date().toISOString(),note:"This confirms the Vercel function is running, not that the retailer's stock API is available."});
}