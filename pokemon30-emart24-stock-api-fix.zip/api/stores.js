export default async function handler(request) {
  try {
    const u = new URL(request.url);
    const search = (u.searchParams.get("search") || "당산").trim();
    const upstream = await fetch("https://emart24.co.kr/api1/store?page=1&search="+encodeURIComponent(search), {
      headers:{"user-agent":"Mozilla/5.0","accept":"application/json, text/plain, */*","referer":"https://emart24.co.kr/"},
      redirect:"follow"
    });
    const raw=await upstream.text();
    let data;
    try { data=JSON.parse(raw); } catch {
      return Response.json({ok:false,error:`이마트24 매장 검색 서버가 JSON이 아닌 응답을 반환했습니다 (HTTP ${upstream.status}).`,upstreamStatus:upstream.status,preview:raw.slice(0,300)},{status:502});
    }
    if(!upstream.ok) return Response.json({ok:false,error:`이마트24 매장 검색 API 오류 (HTTP ${upstream.status})`,upstreamStatus:upstream.status,details:data},{status:502});
    return Response.json(data);
  } catch(e) {
    return Response.json({ok:false,error:"매장 검색 연결 실패: "+String(e?.message||e)},{status:502});
  }
}