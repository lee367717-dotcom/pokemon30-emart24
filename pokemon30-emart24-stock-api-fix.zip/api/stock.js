export default async function handler(request) {
  try {
    const u = new URL(request.url);
    const plu = (u.searchParams.get("pluCd") || "").trim();
    const biz = (u.searchParams.get("bizNoArr") || "").trim();
    if (!plu || !biz) {
      return Response.json({ ok: false, error: "상품코드(pluCd)와 매장코드(bizNoArr)가 필요합니다." }, { status: 400 });
    }

    const base = "https://everse.emart24.co.kr";
    const headers = {
      "x-requested-with": "XMLHttpRequest",
      "accept": "application/json, text/plain, */*",
      "origin": base,
      "referer": base + "/"
    };

    // 1) 앱의 재고조회 준비 요청. 성공 응답 본문이 비어 있을 수 있음.
    const prep = await fetch(base + "/api/stock/v1/search/keyword", {
      method: "POST",
      headers: { ...headers, "content-type": "application/x-www-form-urlencoded; charset=UTF-8" },
      body: new URLSearchParams({ pluCd: plu, searchPage: "STOCK_SEARCH_SERVICE" }),
      redirect: "follow"
    });
    const prepRaw = await prep.text();
    if (!prep.ok) {
      return Response.json({ ok: false, stage: "prepare", error: `재고조회 준비 단계 실패 (HTTP ${prep.status})`, upstreamStatus: prep.status, preview: prepRaw.slice(0, 300) }, { status: 502 });
    }

    // 2) 필수 단계: 상품의 재고 메타정보를 조회하고 성공 여부를 확인.
    const metaRes = await fetch(base + "/api/stock/v1/stock/goods/" + encodeURIComponent(plu), {
      headers,
      redirect: "follow"
    });
    const metaRaw = await metaRes.text();
    let meta;
    try { meta = JSON.parse(metaRaw); }
    catch {
      return Response.json({ ok: false, stage: "product-meta", error: `상품 재고 메타 API가 JSON이 아닌 응답을 반환했습니다 (HTTP ${metaRes.status}).`, upstreamStatus: metaRes.status, preview: metaRaw.slice(0, 300) }, { status: 502 });
    }
    if (!metaRes.ok || (meta.msg && String(meta.msg).toLowerCase() !== "success")) {
      return Response.json({ ok: false, stage: "product-meta", error: `상품 재고 메타 조회 실패 (HTTP ${metaRes.status}, msg=${meta.msg ?? "없음"})`, upstreamStatus: metaRes.status, details: meta }, { status: 502 });
    }

    // 3) 매장별 수량 조회.
    const stockUrl = base + "/api/stock/v2/stock-search/store?searchPluCode=" + encodeURIComponent(plu) + "&bizNoArr=" + encodeURIComponent(biz);
    const stockRes = await fetch(stockUrl, { headers, redirect: "follow" });
    const stockRaw = await stockRes.text();
    let data;
    try { data = JSON.parse(stockRaw); }
    catch {
      return Response.json({ ok: false, stage: "store-stock", error: `매장별 재고 API가 JSON이 아닌 응답을 반환했습니다 (HTTP ${stockRes.status}).`, upstreamStatus: stockRes.status, preview: stockRaw.slice(0, 300) }, { status: 502 });
    }
    if (!stockRes.ok) {
      return Response.json({ ok: false, stage: "store-stock", error: `매장별 재고 API 오류 (HTTP ${stockRes.status})`, upstreamStatus: stockRes.status, details: data }, { status: 502 });
    }
    if (!data || !Array.isArray(data.storeGoodsQty)) {
      return Response.json({ ok: false, stage: "store-stock", error: "응답은 왔지만 storeGoodsQty 배열이 없습니다. API 응답 형식이 변경됐을 수 있습니다.", details: data, productMeta: meta }, { status: 502 });
    }

    return Response.json({ ...data, _productMeta: meta, _checkedAt: new Date().toISOString() });
  } catch (e) {
    return Response.json({ ok: false, stage: "network", error: "이마트24 재고 서버 연결 실패: " + String(e?.message || e) }, { status: 502 });
  }
}
