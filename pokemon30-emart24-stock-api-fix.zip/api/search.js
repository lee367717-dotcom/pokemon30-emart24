export default async function handler(request) {
  try {
    const u = new URL(request.url);
    const keyword = (u.searchParams.get("keyword") || "포켓몬스터 30주년").trim();
    const body = new URLSearchParams({currentPage:"1",pageCnt:"30",sortType:"SALE",saleProductYn:"N",searchWord:keyword});
    const upstream = await fetch("https://everse.emart24.co.kr/stock/stock/search", {
      method:"POST",
      headers:{
        "content-type":"application/x-www-form-urlencoded; charset=UTF-8",
        "x-requested-with":"XMLHttpRequest",
        "accept":"application/json, text/plain, */*",
        "origin":"https://everse.emart24.co.kr",
        "referer":"https://everse.emart24.co.kr/"
      },
      body,
      redirect:"follow"
    });
    const raw = await upstream.text();
    let data;
    try { data=JSON.parse(raw); } catch {
      return Response.json({ok:false,error:`이마트24 상품 검색 서버가 JSON이 아닌 응답을 반환했습니다 (HTTP ${upstream.status}). 로그인/세션 또는 API 주소 변경 가능성.`,upstreamStatus:upstream.status,preview:raw.slice(0,300)}, {status:502});
    }
    if(!upstream.ok) return Response.json({ok:false,error:`이마트24 상품 검색 API 오류 (HTTP ${upstream.status})`,upstreamStatus:upstream.status,details:data},{status:502});
    return Response.json(data);
  } catch(e) {
    return Response.json({ok:false,error:"상품 검색 연결 실패: "+String(e?.message||e)},{status:502});
  }
}